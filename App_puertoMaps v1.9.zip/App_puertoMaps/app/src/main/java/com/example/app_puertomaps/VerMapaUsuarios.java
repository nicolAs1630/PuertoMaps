package com.example.app_puertomaps;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class VerMapaUsuarios extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private FusedLocationProviderClient fusedLocationClient;
    private DatabaseReference eventsReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_mapa_usuarios);

        // Inicializar cliente de ubicación
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // Referencia a eventos en Firebase
        eventsReference = FirebaseDatabase.getInstance().getReference("eventos");

        // Cargar el mapa
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        // Verificar permisos y habilitar ubicación
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        }
        mMap.setMyLocationEnabled(true);

        // Obtener ubicación actual
        fusedLocationClient.getLastLocation().addOnSuccessListener(location -> {
            if (location != null) {
                LatLng userLocation = new LatLng(location.getLatitude(), location.getLongitude());
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 12));
            }
        });

        // Cargar eventos desde Firebase
        cargarEventos();

        // Configurar clic en marcador
        mMap.setOnInfoWindowClickListener(marker -> {
            String eventId = (String) marker.getTag();
            if (eventId != null) {
                mostrarDialogoCalificacion(eventId, marker.getTitle());
            }
        });
    }

    private void cargarEventos() {
        eventsReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                mMap.clear();
                for (DataSnapshot eventSnapshot : snapshot.getChildren()) {
                    // Convertir el snapshot a un objeto Evento
                    Evento evento = eventSnapshot.getValue(Evento.class);
                    if (evento != null) {
                        LatLng eventLocation = new LatLng(evento.getLatitud(), evento.getLongitud());
                        Marker marker = mMap.addMarker(new MarkerOptions()
                                .position(eventLocation)
                                .title(evento.getNombre())
                                .snippet("Inicio: " + evento.getHoraInicio() +
                                        "\nTérmino: " + evento.getHoraFin()));
                        marker.setTag(eventSnapshot.getKey());
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(VerMapaUsuarios.this, "Error al cargar eventos: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void mostrarDialogoCalificacion(String eventId, String eventTitle) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_calificacion, null);
        builder.setView(dialogView);

        RatingBar ratingBar = dialogView.findViewById(R.id.ratingBar);
        EditText etOpinion = dialogView.findViewById(R.id.etOpinion);
        Button btnEnviar = dialogView.findViewById(R.id.btnEnviarCalificacion);

        AlertDialog dialog = builder.create();

        btnEnviar.setOnClickListener(view -> {
            float calificacion = ratingBar.getRating();
            String opinion = etOpinion.getText().toString().trim();

            if (calificacion == 0 || opinion.isEmpty()) {
                Toast.makeText(this, "Por favor, proporciona una calificación y una opinión", Toast.LENGTH_SHORT).show();
            } else {
                enviarCalificacion(eventId, calificacion, opinion);
                dialog.dismiss();
            }
        });

        dialog.setTitle("Calificar: " + eventTitle);
        dialog.show();
    }

    private void enviarCalificacion(String eventId, float calificacion, String opinion) {
        DatabaseReference calificacionesRef = eventsReference.child(eventId).child("calificaciones");
        String calificacionId = calificacionesRef.push().getKey();

        HashMap<String, Object> calificacionMap = new HashMap<>();
        calificacionMap.put("calificacion", calificacion);
        calificacionMap.put("opinion", opinion);

        calificacionesRef.child(calificacionId).setValue(calificacionMap).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(this, "Calificación enviada con éxito", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Error al enviar calificación", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                onMapReady(mMap);
            } else {
                Toast.makeText(this, "Permiso de ubicación denegado", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
