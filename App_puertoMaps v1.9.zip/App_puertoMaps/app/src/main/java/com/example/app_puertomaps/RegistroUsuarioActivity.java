package com.example.app_puertomaps;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class RegistroUsuarioActivity extends AppCompatActivity {

    private EditText nombreUsuario, correoUsuario, contraseñaUsuario, confirmContraseña;
    private Button registrarButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_usuario);

        nombreUsuario = findViewById(R.id.etNombre);
        correoUsuario = findViewById(R.id.etCorreoRegistro);
        contraseñaUsuario = findViewById(R.id.etContraseñaRegistro);
        confirmContraseña = findViewById(R.id.etConfirmContraseña);
        registrarButton = findViewById(R.id.btnRegistrarUsuario);

        registrarButton.setOnClickListener(view -> {
            if (validarCampos()) {
                registrarUsuario();
            }
        });
    }

    private boolean validarCampos() {
        String nombre = nombreUsuario.getText().toString().trim();
        String correo = correoUsuario.getText().toString().trim();
        String contraseña = contraseñaUsuario.getText().toString().trim();
        String confirm = confirmContraseña.getText().toString().trim();

        if (TextUtils.isEmpty(nombre)) {
            nombreUsuario.setError("El nombre no puede estar vacío");
            return false;
        }
        if (TextUtils.isEmpty(correo) || !android.util.Patterns.EMAIL_ADDRESS.matcher(correo).matches()) {
            correoUsuario.setError("Ingresa un correo válido");
            return false;
        }
        if (TextUtils.isEmpty(contraseña) || contraseña.length() < 6) {
            contraseñaUsuario.setError("La contraseña debe tener al menos 6 caracteres");
            return false;
        }
        if (!contraseña.equals(confirm)) {
            confirmContraseña.setError("Las contraseñas no coinciden");
            return false;
        }
        return true;
    }

    private void registrarUsuario() {
        String nombre = nombreUsuario.getText().toString().trim();
        String correo = correoUsuario.getText().toString().trim();
        String contraseña = contraseñaUsuario.getText().toString().trim();

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("users");
        String userId = reference.push().getKey();

        HashMap<String, String> userMap = new HashMap<>();
        userMap.put("id", userId);
        userMap.put("name", nombre);
        userMap.put("email", correo);
        userMap.put("password", contraseña);

        reference.child(userId).setValue(userMap).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(this, "Usuario registrado exitosamente", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "Error al registrar el usuario", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
