package com.example.app_puertomaps;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class VisitorModeActivity extends FragmentActivity implements OnMapReadyCallback, GoogleMap.OnMarkerClickListener {

    private GoogleMap mMap;
    private FusedLocationProviderClient fusedLocationClient;
    private LocationCallback locationCallback;
    private ArrayList<Evento> eventos; // Lista de eventos

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modo_visitante);

        // Inicializar servicios de ubicación
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // Configurar el mapa
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        // Callback de ubicación para actualizar el mapa con la nueva ubicación
        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null) {
                    return;
                }
                if (mMap != null) {
                    android.location.Location location = locationResult.getLastLocation();
                    LatLng currentLocation = new LatLng(location.getLatitude(), location.getLongitude());
                }
            }
        };
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setOnMarkerClickListener(this);

        // Verificar permisos de ubicación y solicitar actualizaciones de ubicación
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            mMap.setMyLocationEnabled(true);
            LocationRequest locationRequest = LocationRequest.create();
            locationRequest.setInterval(10000); // Intervalo de actualización en milisegundos
            locationRequest.setFastestInterval(5000); // Intervalo más rápido
            locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

            fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);
        } else {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        }

        // Recibir y mostrar eventos desde el Intent
        recibirYMostrarEventos();
        cargarEventosDesdeFirebase();

        // Si no hay eventos desde el intent, cargar eventos ficticios
        if (eventos == null || eventos.isEmpty()) {
            cargarEventosFicticios();
            Toast.makeText(this, "Mapa cargado con eventos ficticios", Toast.LENGTH_SHORT).show();
        }
    }

    private void recibirYMostrarEventos() {
        // Obtener los eventos del intent
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("eventos")) {
            eventos = intent.getParcelableArrayListExtra("eventos");
        } else {
            eventos = new ArrayList<>(); // Inicializar lista vacía
        }

        // Agregar marcadores para cada evento
        for (Evento evento : eventos) {
            LatLng eventLocation = new LatLng(evento.getLatitud(), evento.getLongitud());
            Marker marker = mMap.addMarker(new MarkerOptions()
                    .position(eventLocation)
                    .title(evento.getNombre())
                    .snippet(evento.getDescripcion())
                    .icon(BitmapDescriptorFactory.defaultMarker(getMarkerColor(evento))));
            marker.setTag(evento); // Almacenar detalles del evento en el tag del marcador
        }

        if (!eventos.isEmpty()) {
            LatLng firstEventLocation = new LatLng(eventos.get(0).getLatitud(), eventos.get(0).getLongitud());
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(firstEventLocation, 14));
        }
    }

    private void cargarEventosDesdeFirebase() {
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("eventos");

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    eventos.clear(); // Limpiar la lista para evitar duplicados
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                        Evento evento = dataSnapshot.getValue(Evento.class);
                        if (evento != null) {
                            eventos.add(evento);
                            LatLng eventLocation = new LatLng(evento.getLatitud(), evento.getLongitud());
                            Marker marker = mMap.addMarker(new MarkerOptions()
                                    .position(eventLocation)
                                    .title(evento.getNombre())
                                    .snippet(evento.getDescripcion())
                                    .icon(BitmapDescriptorFactory.defaultMarker(getMarkerColor(evento))));
                            marker.setTag(evento);
                        }
                    }

                    if (!eventos.isEmpty()) {
                        LatLng firstEventLocation = new LatLng(eventos.get(0).getLatitud(), eventos.get(0).getLongitud());
                        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(firstEventLocation, 14));
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(VisitorModeActivity.this, "Error al cargar eventos: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void cargarEventosFicticios() {
        // Lista de eventos ficticios
        List<Evento> eventosFicticios = new ArrayList<>();
        eventosFicticios.add(new Evento(
                "1",
                "locatario1@example.com",
                "Festival de Música",
                "Un increíble festival con artistas internacionales.",
                "01:00",
                "02:00",
                -41.469833, -72.941399 // Coordenadas ficticias
        ));
        eventosFicticios.add(new Evento(
                "2",
                "locatario2@example.com",
                "Feria de Comida",
                "Disfruta de deliciosos platos locales y artesanías.",
                "10:00",
                "18:00",
                -41.471277, -72.935501
        ));
        eventosFicticios.add(new Evento(
                "3",
                "locatario3@example.com",
                "Concierto de Jazz",
                "Una noche inolvidable con los mejores artistas de jazz.",
                "20:00",
                "22:00",
                -41.473933, -72.937123
        ));

        // Agregar marcadores al mapa
        for (Evento evento : eventosFicticios) {
            LatLng position = new LatLng(evento.getLatitud(), evento.getLongitud());
            Marker marker = mMap.addMarker(new MarkerOptions()
                    .position(position)
                    .title(evento.getNombre())
                    .snippet(evento.getDescripcion())
                    .icon(BitmapDescriptorFactory.defaultMarker(getMarkerColor(evento))));
            marker.setTag(evento);
        }
    }

    // Método para obtener el color del marcador según el estado del evento
    private float getMarkerColor(Evento evento) {
        try {
            SimpleDateFormat format = new SimpleDateFormat("HH:mm", Locale.getDefault());
            Date currentDate = new Date(); // Obtiene la hora actual

            // Validar que las horas no sean nulas o vacías
            String horaInicio = evento.getHoraInicio();
            String horaFin = evento.getHoraFin();

            if (horaInicio == null || horaInicio.isEmpty() || horaFin == null || horaFin.isEmpty()) {
                return BitmapDescriptorFactory.HUE_ORANGE; // Color por defecto si hay datos inválidos
            }

            // Parsear las horas de inicio y fin
            Date startTime = format.parse(horaInicio);
            Date endTime = format.parse(horaFin);

            if (startTime != null && endTime != null) {
                if (currentDate.before(startTime)) {
                    // Evento por empezar: Amarillo
                    long diffInMinutes = (startTime.getTime() - currentDate.getTime()) / (1000 * 60);
                    if (diffInMinutes <= 15) {
                        return BitmapDescriptorFactory.HUE_YELLOW; // Amarillo si el evento empieza en menos de 15 minutos
                    }
                } else if (currentDate.after(endTime)) {
                    // Evento finalizado: Rojo
                    return BitmapDescriptorFactory.HUE_RED;
                } else {
                    // Evento en curso: Verde
                    return BitmapDescriptorFactory.HUE_GREEN;
                }
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return BitmapDescriptorFactory.HUE_ORANGE; // Default: Naranja si no se puede determinar
    }



    @Override
    public boolean onMarkerClick(Marker marker) {
        // Mostrar los detalles del evento al hacer clic en el marcador
        Evento evento = (Evento) marker.getTag();
        if (evento != null) {
            showEventDetails(evento);
        }
        return true;
    }

    private void showEventDetails(Evento evento) {
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        View bottomSheetView = LayoutInflater.from(this).inflate(R.layout.bottom_sheet_evento_detalles, null);
        bottomSheetDialog.setContentView(bottomSheetView);

        TextView tvNombreEvento = bottomSheetView.findViewById(R.id.tvTitulo);
        TextView tvDescripcionEvento = bottomSheetView.findViewById(R.id.tvDescripcion);
        TextView tvHoraInicioEvento = bottomSheetView.findViewById(R.id.tvHoraInicio);
        TextView tvHoraFinEvento = bottomSheetView.findViewById(R.id.tvHoraFin);
        ImageView imgEventoDetalles = bottomSheetView.findViewById(R.id.imgEventoDetalles);

        tvNombreEvento.setText(evento.getNombre());
        tvDescripcionEvento.setText(evento.getDescripcion());
        tvHoraInicioEvento.setText("Hora de Inicio: " + evento.getHoraInicio());
        tvHoraFinEvento.setText("Hora de Fin: " + evento.getHoraFin());
        // Asumimos que tienes un método getImagenUri en tu clase Evento para obtener la URI de la imagen
        String imagenUri = evento.getImagenUri();
        if (imagenUri != null && !imagenUri.isEmpty()) {
            imgEventoDetalles.setImageURI(Uri.parse(imagenUri));
        }

        bottomSheetDialog.show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (fusedLocationClient != null) {
            fusedLocationClient.removeLocationUpdates(locationCallback);
        }
    }
}