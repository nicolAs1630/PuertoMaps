package com.example.app_puertomaps;

import android.annotation.SuppressLint;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;
import java.util.HashMap;

public class VerMapaLocatarios extends AppCompatActivity implements OnMapReadyCallback {
    private static final int PICK_IMAGE_REQUEST = 1;

    private GoogleMap mMap;
    private String emailLocatario;
    private Button btnAgregarEvento;
    private EditText etHoraInicio, etHoraFin, etTipoEvento;

    private Marker eventoMarker;
    private String nombreEvento, descripcionEvento, horaInicio, horaFin;
    private Uri selectedImageUri;

    private LatLng eventoPosition;
    private FusedLocationProviderClient fusedLocationClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_mapa_locatarios);

        // Obtener el correo del locatario desde el Intent
        emailLocatario = getIntent().getStringExtra("email");

        // Inicializar el cliente de ubicación
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // Configuración de la interfaz de usuario
        btnAgregarEvento = findViewById(R.id.btnAgregarEvento);

        // Configuración de la vista de borde a borde
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Inicializar el mapa
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        // Configuración del botón de agregar evento
        btnAgregarEvento.setOnClickListener(v -> mostrarFormularioEvento());
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        // Listener para mostrar detalles de los marcadores
        mMap.setOnMarkerClickListener(marker -> {
            if (marker.equals(eventoMarker)) {
                mostrarDetallesEvento();
                return true;
            }
            return false;
        });

        // Check for location permissions and get the current location
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            fusedLocationClient.getLastLocation().addOnCompleteListener(this, task -> {
                if (task.isSuccessful() && task.getResult() != null) {
                    android.location.Location location = task.getResult();
                    LatLng currentLocation = new LatLng(location.getLatitude(), location.getLongitude());
                    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLocation, 14));
                    mMap.addMarker(new MarkerOptions().position(currentLocation).title("Tu Local ")
                            .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));
                } else {
                    Toast.makeText(VerMapaLocatarios.this, "Unable to get location", Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        }

        // Cargar evento registrado
        cargarEventoRegistrado();

        Toast.makeText(this, "Mapa listo para mostrar información del locatario", Toast.LENGTH_SHORT).show();
    }

    private void cargarEventoRegistrado() {
        DatabaseReference eventosRef = FirebaseDatabase.getInstance().getReference("eventos");

        eventosRef.orderByChild("emailLocatario").equalTo(emailLocatario)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        for (DataSnapshot eventoSnapshot : task.getResult().getChildren()) {
                            // Extraer datos del evento
                            nombreEvento = eventoSnapshot.child("nombre").getValue(String.class);
                            descripcionEvento = eventoSnapshot.child("descripcion").getValue(String.class);
                            horaInicio = eventoSnapshot.child("horaInicio").getValue(String.class);
                            horaFin = eventoSnapshot.child("horaFin").getValue(String.class);
                            double latitud = eventoSnapshot.child("latitud").getValue(Double.class);
                            double longitud = eventoSnapshot.child("longitud").getValue(Double.class);

                            String imagenUri = eventoSnapshot.child("imagenUri").getValue(String.class);
                            if (imagenUri != null) {
                                selectedImageUri = Uri.parse(imagenUri); // Guardar URI de Firebase
                            }

                            eventoPosition = new LatLng(latitud, longitud);
                            agregarMarcadorMapa(eventoPosition);
                        }
                    } else {
                        Toast.makeText(this, "No se encontraron eventos registrados.", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Error al cargar el evento: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }
    private void mostrarFormularioEvento() {
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        View bottomSheetView = LayoutInflater.from(this).inflate(R.layout.bottom_sheet_evento, null);
        bottomSheetDialog.setContentView(bottomSheetView);

        EditText txtEventoNombre = bottomSheetView.findViewById(R.id.etTitulo);
        EditText txtEventoDescripcion = bottomSheetView.findViewById(R.id.etDescripcion);
        Button btnHoraInicio = bottomSheetView.findViewById(R.id.btnHoraInicio);
        Button btnHoraFin = bottomSheetView.findViewById(R.id.btnHoraFin);
        Button btnAgregarImagen = bottomSheetView.findViewById(R.id.btnAgregarImagen);
        Button btnGuardarEvento = bottomSheetView.findViewById(R.id.btnGuardar);

        btnHoraInicio.setOnClickListener(v -> seleccionarHora(true));
        btnHoraFin.setOnClickListener(v -> seleccionarHora(false));
        btnAgregarImagen.setOnClickListener(v -> seleccionarImagen());

        btnGuardarEvento.setOnClickListener(v -> {
            String nombreEvento = txtEventoNombre.getText().toString().trim();
            String descripcionEvento = txtEventoDescripcion.getText().toString().trim();

            if (nombreEvento.isEmpty() || descripcionEvento.isEmpty() || horaInicio == null || horaFin == null) {
                Toast.makeText(this, "Por favor completa todos los campos", Toast.LENGTH_SHORT).show();
                return;
            }

            // Obtener la ubicación actual y guardar el evento
            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                fusedLocationClient.getLastLocation().addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        android.location.Location location = task.getResult();
                        LatLng currentLocation = new LatLng(location.getLatitude(), location.getLongitude());

                        DatabaseReference eventosRef = FirebaseDatabase.getInstance().getReference("eventos");
                        String eventoId = eventosRef.push().getKey();

                        Evento evento = new Evento(
                                eventoId,
                                emailLocatario,
                                nombreEvento,
                                descripcionEvento,
                                horaInicio,
                                horaFin,
                                currentLocation.latitude,
                                currentLocation.longitude
                        );

                        eventosRef.child(eventoId).setValue(evento).addOnCompleteListener(task1 -> {
                            if (task1.isSuccessful()) {
                                Toast.makeText(this, "Evento agregado exitosamente", Toast.LENGTH_SHORT).show();
                                bottomSheetDialog.dismiss();

                                // Enviar el evento a VisitorModeActivity
                                eventoPosition = new LatLng(currentLocation.latitude, currentLocation.longitude);
                                agregarMarcadorMapa(eventoPosition);
                                Intent intent = new Intent(VerMapaLocatarios.this, VisitorModeActivity.class);
                                intent.putExtra("nombre", nombreEvento);
                                intent.putExtra("descripcion", descripcionEvento);
                                intent.putExtra("horaInicio", horaInicio);
                                intent.putExtra("horaFin", horaFin);
                                intent.putExtra("latitud", currentLocation.latitude);
                                intent.putExtra("longitud", currentLocation.longitude);
                                startActivity(intent);
                            } else {
                                Toast.makeText(this, "Error al agregar el evento", Toast.LENGTH_SHORT).show();
                            }
                        });
                    } else {
                        Toast.makeText(this, "No se puede obtener la ubicación :(", Toast.LENGTH_SHORT).show();
                    }
                });
            } else {
                ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            }
        });

        bottomSheetDialog.show();
    }



    private void seleccionarHora(boolean esHoraInicio) {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                (TimePicker view, int hourOfDay, int minuteOfHour) -> {
                    String horaSeleccionada = String.format("%02d:%02d", hourOfDay, minuteOfHour);
                    if (esHoraInicio) {
                        horaInicio = horaSeleccionada;
                    } else {
                        horaFin = horaSeleccionada;
                    }
                }, hour, minute, true);

        timePickerDialog.show();
    }

    private void seleccionarImagen() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedImageUri = data.getData();
            Toast.makeText(this, "Imagen seleccionada", Toast.LENGTH_SHORT).show();
        }
    }

    private void agregarMarcadorMapa(LatLng position) {
        if (mMap != null) {
            if (eventoMarker != null) {
                eventoMarker.remove();
            }

            eventoMarker = mMap.addMarker(new MarkerOptions()
                    .position(position)
                    .title(nombreEvento));
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(position, 14));
        }
    }

    @SuppressLint("WrongViewCast")
    private void limpiarCampos() {
        // Inicializa las referencias dentro del método limpiarCampos
        etHoraInicio = findViewById(R.id.btnHoraInicio);
        etHoraFin = findViewById(R.id.btnHoraFin);

        // Asegúrate de que las referencias no sean nulas antes de usarlas
        if (etHoraInicio != null) etHoraInicio.setText("");
        if (etHoraFin != null) etHoraFin.setText("");
    }

    private void mostrarDetallesEvento() {
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        View bottomSheetView = LayoutInflater.from(this).inflate(R.layout.bottom_sheet_evento_detalles, null);
        bottomSheetDialog.setContentView(bottomSheetView);

        TextView tvTitulo = bottomSheetView.findViewById(R.id.tvTitulo);
        TextView tvDescripcion = bottomSheetView.findViewById(R.id.tvDescripcion);
        TextView txtHoraInicio = bottomSheetView.findViewById(R.id.tvHoraInicio);
        TextView txtHoraFin = bottomSheetView.findViewById(R.id.tvHoraFin);
        ImageView imgEvento = bottomSheetView.findViewById(R.id.imgEventoDetalles);

        // Set the details from the recently added event
        tvTitulo.setText(nombreEvento);
        tvDescripcion.setText(descripcionEvento);
        txtHoraInicio.setText("Hora de inicio: " + horaInicio);
        txtHoraFin.setText("Hora de término: " + horaFin);

        // Set the image if an image was selected
        if (selectedImageUri != null) {
            imgEvento.setImageURI(selectedImageUri);
        }

        bottomSheetDialog.show();
    }
}


