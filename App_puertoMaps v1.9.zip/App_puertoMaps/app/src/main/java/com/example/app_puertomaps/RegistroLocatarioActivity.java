package com.example.app_puertomaps;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class RegistroLocatarioActivity extends AppCompatActivity {

    private EditText etNombreLocatario, etCorreoLocatario, etNombreLocal, etDireccionLocal,
            etTelefonoLocatario, etPasswordLocatario;
    private Button btnRegistrarLocatario;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_locatario);

        etNombreLocatario = findViewById(R.id.etNombreLocatario);
        etCorreoLocatario = findViewById(R.id.etCorreoLocatario);
        etNombreLocal = findViewById(R.id.etNombreLocal);
        etDireccionLocal = findViewById(R.id.etDireccionLocal);
        etTelefonoLocatario = findViewById(R.id.etTelefonoLocatario);
        etPasswordLocatario = findViewById(R.id.etPasswordLocatario);
        btnRegistrarLocatario = findViewById(R.id.btnRegistrarLocatario);

        btnRegistrarLocatario.setOnClickListener(view -> registrarLocatario());
    }

    private void registrarLocatario() {
        String nombre = etNombreLocatario.getText().toString().trim();
        String correo = etCorreoLocatario.getText().toString().trim();
        String nombreLocal = etNombreLocal.getText().toString().trim();
        String direccion = etDireccionLocal.getText().toString().trim();
        String telefono = etTelefonoLocatario.getText().toString().trim();
        String contraseña = etPasswordLocatario.getText().toString().trim();

        // Validación de campos vacíos
        if (nombre.isEmpty() || correo.isEmpty() || nombreLocal.isEmpty() || direccion.isEmpty()
                || telefono.isEmpty() || contraseña.isEmpty()) {
            Toast.makeText(this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        try {


            DatabaseReference reference = FirebaseDatabase.getInstance().getReference("locatarios");
            String locatarioId = reference.push().getKey();

            HashMap<String, Object> locatarioMap = new HashMap<>();
            locatarioMap.put("id", locatarioId);
            locatarioMap.put("name", nombre);
            locatarioMap.put("email", correo);
            locatarioMap.put("localName", nombreLocal);
            locatarioMap.put("address", direccion);
            locatarioMap.put("phone", telefono);
            locatarioMap.put("password", contraseña);


            reference.child(locatarioId).setValue(locatarioMap).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    Toast.makeText(this, "Locatario registrado exitosamente", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(this, "Error al registrar locatario", Toast.LENGTH_SHORT).show();
                }
            });

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Latitud y longitud deben ser números válidos", Toast.LENGTH_SHORT).show();
        }
    }
}
