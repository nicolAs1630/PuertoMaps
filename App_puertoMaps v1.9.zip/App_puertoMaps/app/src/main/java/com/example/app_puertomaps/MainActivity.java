package com.example.app_puertomaps;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    private EditText loginCorreo, loginPassword;
    private Button loginButton, registerButton, visitanteButton;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        loginCorreo = findViewById(R.id.etCorreo);
        loginPassword = findViewById(R.id.etContraseña);
        loginButton = findViewById(R.id.btnIniciarSesion);
        registerButton = findViewById(R.id.btnRegistro);
        visitanteButton = findViewById(R.id.btnmodovisitante);

        loginButton.setOnClickListener(view -> {
            if (!validateEmail() || !validatePassword()) {
                return;
            }
            checkUser();
        });


        registerButton.setOnClickListener(view -> irRegistroActivity(view));

        Button visitanteButton=findViewById(R.id.btnmodovisitante);
        visitanteButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, VisitorModeActivity.class);
            startActivity(intent);
        });

    }

    private boolean validateEmail() {
        String val = loginCorreo.getText().toString().trim();
        if (val.isEmpty()) {
            loginCorreo.setError("El correo no puede estar vacío");
            return false;
        }
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(val).matches()) {
            loginCorreo.setError("Correo inválido");
            return false;
        }
        return true;
    }

    private boolean validatePassword() {
        String val = loginPassword.getText().toString().trim();
        if (val.isEmpty()) {
            loginPassword.setError("La contraseña no puede estar vacía");
            return false;
        }
        return true;
    }

    private void checkUser() {
        String userEmail = loginCorreo.getText().toString().trim();
        String userPassword = loginPassword.getText().toString().trim();

        DatabaseReference usersRef = FirebaseDatabase.getInstance().getReference("users");
        DatabaseReference locatariosRef = FirebaseDatabase.getInstance().getReference("locatarios");

        Query userQuery = usersRef.orderByChild("email").equalTo(userEmail);
        userQuery.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    for (DataSnapshot userSnapshot : snapshot.getChildren()) {
                        String passwordFromDB = userSnapshot.child("password").getValue(String.class);
                        if (passwordFromDB != null && passwordFromDB.equals(userPassword)) {
                            String nameFromDB = userSnapshot.child("name").getValue(String.class);
                            Intent intent = new Intent(MainActivity.this, VerMapaUsuarios.class);
                            intent.putExtra("name", nameFromDB);
                            intent.putExtra("email", userEmail);
                            startActivity(intent);
                            return;
                        }
                    }
                    loginPassword.setError("Contraseña incorrecta");
                    loginPassword.requestFocus();
                } else {
                    Query locatarioQuery = locatariosRef.orderByChild("email").equalTo(userEmail);
                    locatarioQuery.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.exists()) {
                                for (DataSnapshot locatarioSnapshot : snapshot.getChildren()) {
                                    String passwordFromDB = locatarioSnapshot.child("password").getValue(String.class);
                                    if (passwordFromDB != null && passwordFromDB.equals(userPassword)) {
                                        String nameFromDB = locatarioSnapshot.child("name").getValue(String.class);

                                        Intent intent = new Intent(MainActivity.this, VerMapaLocatarios.class);
                                        intent.putExtra("name", nameFromDB);
                                        intent.putExtra("email", userEmail);
                                        startActivity(intent);
                                        return;
                                    }
                                }
                                loginPassword.setError("Contraseña incorrecta");
                                loginPassword.requestFocus();
                            } else {
                                loginCorreo.setError("El correo no está registrado");
                                loginCorreo.requestFocus();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Toast.makeText(MainActivity.this, "Error al acceder a Firebase: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "Error al acceder a Firebase: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void irRegistroActivity(View vista) {
        Intent miIntent = new Intent(this, RegistroLocatarioActivity.class);
        startActivity(miIntent);
    }

}

