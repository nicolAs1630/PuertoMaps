package com.example.app_puertomaps;

public class Rating {
    private String userId;
    private float rating;
    private String comment;

    public Rating() {}

    public Rating(String userId, float rating, String comment) {
        this.userId = userId;
        this.rating = rating;
        this.comment = comment;
    }

    // Getters y setters si es necesario
}
