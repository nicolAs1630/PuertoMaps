package com.example.app_puertomaps;

public class Locatario {
    private String nombre, correo, nombreLocal, direccion, telefono;

    public Locatario() {
    }

    public Locatario(String nombre, String correo, String nombreLocal, String direccion, String telefono) {
        this.nombre = nombre;
        this.correo = correo;
        this.nombreLocal = nombreLocal;
        this.direccion = direccion;
        this.telefono = telefono;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public String getNombreLocal() {
        return nombreLocal;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getTelefono() {
        return telefono;
    }
}
