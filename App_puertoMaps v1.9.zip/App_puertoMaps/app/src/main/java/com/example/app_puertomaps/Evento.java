package com.example.app_puertomaps;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Evento implements Parcelable {
    private String id;
    private String emailLocatario;
    private String nombre;
    private String descripcion;
    private String horaInicio;
    private String horaFin;
    private double latitud;
    private double longitud;
    private String imagenUri;

    // Constructor vacío necesario para Firebase
    public Evento() {}

    // Constructor
    public Evento(String id, String emailLocatario, String nombre, String descripcion,
                  String horaInicio, String horaFin, double latitud, double longitud) {
        this.id = id;
        this.emailLocatario = emailLocatario;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
        this.latitud = latitud;
        this.longitud = longitud;
        this.imagenUri = null;
    }

    // Parcelable Constructor
    protected Evento(Parcel in) {
        id = in.readString();
        emailLocatario = in.readString();
        nombre = in.readString();
        descripcion = in.readString();
        horaInicio = in.readString();
        horaFin = in.readString();
        latitud = in.readDouble();
        longitud = in.readDouble();
        imagenUri = in.readString();
    }

    // Parcelable Creator
    public static final Creator<Evento> CREATOR = new Creator<Evento>() {
        @Override
        public Evento createFromParcel(Parcel in) {
            return new Evento(in);
        }

        @Override
        public Evento[] newArray(int size) {
            return new Evento[size];
        }
    };

    // Parcelable method implementations
    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(emailLocatario);
        dest.writeString(nombre);
        dest.writeString(descripcion);
        dest.writeString(horaInicio);
        dest.writeString(horaFin);
        dest.writeDouble(latitud);
        dest.writeDouble(longitud);
        dest.writeString(imagenUri);
    }

    // Existing getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getEmailLocatario() { return emailLocatario; }
    public void setEmailLocatario(String emailLocatario) { this.emailLocatario = emailLocatario; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public String getHoraInicio() { return horaInicio; }
    public void setHoraInicio(String horaInicio) { this.horaInicio = horaInicio; }

    public String getHoraFin() { return horaFin; }
    public void setHoraFin(String horaFin) { this.horaFin = horaFin; }

    public double getLatitud() { return latitud; }
    public void setLatitud(double latitud) { this.latitud = latitud; }

    public double getLongitud() { return longitud; }
    public void setLongitud(double longitud) { this.longitud = longitud; }

    public void setImagenUri(String uriString) {
        this.imagenUri = uriString;
    }

    public String getImagenUri() {
        return imagenUri;
    }
}